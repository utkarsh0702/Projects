from sklearn.model_selection import cross_val_score, KFold
from sklearn.ensemble import GradientBoostingClassifier
from sklearn import metrics
import numpy as np
import pandas as pd
from sklearn import preprocessing

df2 = pd.read_csv(r'C:\Users\Utkarsh\Desktop\churn.csv')
df1= df2.replace(to_replace='?',value= np.nan)
df= df1.dropna()
df['Churn?'][df['Churn?']=='True.']=1
df['Churn?'][df['Churn?']=='False.']=0
df["Int'l Plan"][df["Int'l Plan"]=='yes']=1
df["Int'l Plan"][df["Int'l Plan"]=='no']=0
df["VMail Plan"][df["VMail Plan"]=='yes']=1
df["VMail Plan"][df["VMail Plan"]=='no']=0

y = df['Churn?'].as_matrix().astype(np.int)
df.drop(["Phone","Churn?"], axis = 1, inplace=True)

label_encoder = preprocessing.LabelEncoder()
df['State'] = label_encoder.fit_transform(df['State'])

X = df.as_matrix().astype(np.float)
scaler = preprocessing.StandardScaler()
X = scaler.fit_transform(X)

model = ensemble.GradientBoostingClassifier()
kfold = KFold(n_splits=10, random_state=7)
result = cross_val_score(model, X, y, cv=kfold, scoring='roc_auc')
print(result.mean())